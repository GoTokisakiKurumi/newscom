<div class="tabspasi slide"></div>
<div class="sec-berita">
  <img src="../Public/image/thumbnails/b.png">
  <div class="sec-berita-text">
    <p><a href="#">8 Rekening Terkait Kasus Doni Salmanan Diblokir Bareskrim!</a></p>
    <span class="tgl-post">1 menit yang lalu | News.com</span>
  </div>
</div>
<div class="sec-berita">
  <img src="../Public/image/thumbnails/d.png">
  <div class="sec-berita-text">
    <p><a href="#">8 Rekening Terkait Kasus Doni Salmanan Diblokir Bareskrim!</a></p>
    <span class="tgl-post">5 menit yang lalu | News.com</span>
  </div>
</div>
<div class="sec-berita">
  <img src="../Public/image/thumbnails/c.png">
  <div class="sec-berita-text">
    <p><a href="#">8 Rekening Terkait Kasus Doni Salmanan Diblokir Bareskrim!</a></p>
    <span class="tgl-post">1 jam yang lalu | News.com</span>
  </div>
</div>
<div class="sec-berita">
  <img src="../Public/image/thumbnails/e.png">
  <div class="sec-berita-text">
    <p><a href="#">8 Rekening Terkait Kasus Doni Salmanan Diblokir Bareskrim!</a></p>
    <span class="tgl-post">5 jam yang lalu | News.com</span>
  </div>
</div>
<div class="sec-berita">
  <img src="../Public/image/thumbnails/a.png">
  <div class="sec-berita-text">
    <p><a href="#">8 Rekening Terkait Kasus Doni Salmanan Diblokir Bareskrim!</a></p>
    <span class="tgl-post">15 jam yang lalu | News.com</span>
  </div>
</div>
<div class="sec-berita">
  <img src="../Public/image/thumbnails/f.png">
  <div class="sec-berita-text">
    <p><a href="#">8 Rekening Terkait Kasus Doni Salmanan Diblokir Bareskrim!</a></p>
    <span class="tgl-post">17 jam yang lalu | News.com</span>
  </div>
</div>
<div class="sec-berita">
  <img src="../Public/image/thumbnails/g.png">
  <div class="sec-berita-text">
    <p><a href="#">8 Rekening Terkait Kasus Doni Salmanan Diblokir Bareskrim!</a></p>
    <span class="tgl-post">20 jam yang lalu | News.com</span>
  </div>
</div>
<div class="sec-berita">
  <img src="../Public/image/thumbnails/i.png">
  <div class="sec-berita-text">
    <p><a href="#">8 Rekening Terkait Kasus Doni Salmanan Diblokir Bareskrim!</a></p>
    <span class="tgl-post">21 jam yang lalu | News.com</span>
  </div>
</div>
<div class="sec-berita">
  <img src="../Public/image/thumbnails/d.png">
  <div class="sec-berita-text">
    <p><a href="#">8 Rekening Terkait Kasus Doni Salmanan Diblokir Bareskrim!</a></p>
    <span class="tgl-post">24 jam yang lalu | News.com</span>
  </div>
</div>
