<div class="tabspasi slide"></div>
<div class="container-videos">
  <div class="thumbnails-videos">
    <div class="durasi-videos">
      <i class="fa-solid fa-video"></i>
      <h6>02:30</h6>
    </div>
    <a href="video">
      <img src="../Public/image/thumbnails/videos/a.png">
    </a>
    <p>Lorem Ipsum is simply dummy text 
    of the printing and typesetting industry</p>
    <p class="V_Time">1 jam yang lalu</p>
  </div>
  <div class="thumbnails-videos">
    <div class="durasi-videos">
      <i class="fa-solid fa-video"></i>
      <h6>04:56</h6>
    </div>
    <a href="#">
      <img src="../Public/image/thumbnails/videos/b.png">
    </a>
    <p>Lorem Ipsum is simply dummy text 
    of the printing and typesetting industry</p>
    <p class="V_Time">2 jam yang lalu</p>
  </div>
  <div class="thumbnails-videos">
    <div class="durasi-videos">
      <i class="fa-solid fa-video"></i>
      <h6>05:33</h6>
    </div>
    <a href="#">
      <img src="../Public/image/thumbnails/videos/c.png">
    </a>
    <p>Lorem Ipsum is simply dummy text 
    of the printing and typesetting industry</p>
    <p class="V_Time">4 jam yang lalu</p>
  </div>
  <div class="thumbnails-videos">
    <div class="durasi-videos">
      <i class="fa-solid fa-video"></i>
      <h6>03:10</h6>
    </div>
    <a href="#">
      <img src="../Public/image/thumbnails/videos/d.png">
    </a>
    <p>Lorem Ipsum is simply dummy text 
    of the printing and typesetting industry</p>
    <p class="V_Time">5 jam yang lalu</p>
  </div>
  <div class="thumbnails-videos">
    <div class="durasi-videos">
      <i class="fa-solid fa-video"></i>
      <h6>01:40</h6>
    </div>
    <a href="#">
      <img src="../Public/image/thumbnails/videos/e.png">
    </a>
    <p>Lorem Ipsum is simply dummy text 
    of the printing and typesetting industry</p>
    <p class="V_Time">7 jam yang lalu</p>
  </div>
  <div class="thumbnails-videos">
    <div class="durasi-videos">
      <i class="fa-solid fa-video"></i>
      <h6>06:03</h6>
    </div>
    <a href="#">
      <img src="../Public/image/thumbnails/videos/f.png">
    </a>
    <p>Lorem Ipsum is simply dummy text 
    of the printing and typesetting industry</p>
    <p class="V_Time">8 jam yang lalu</p>
  </div>
  <div class="thumbnails-videos">
    <div class="durasi-videos">
      <i class="fa-solid fa-video"></i>
      <h6>03:37</h6>
    </div>
    <a href="#">
      <img src="../Public/image/thumbnails/videos/g.png">
    </a>
    <p>Lorem Ipsum is simply dummy text 
    of the printing and typesetting industry</p>
    <p class="V_Time">9 jam yang lalu</p>
  </div>
</div>
