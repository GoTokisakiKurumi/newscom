<div class="container-head">
  <header class="headers">
    <div class="slide fade">
      <div class="text">
        <p>Gempa Bumi Mengguncang Kota Tasikmalaya</p>
      </div>
      <span class="bgtext"></span>
      <img src="<?= BASEURL; ?>/image/sliders/slide1.png">
     </div>
     <div class="slide fade">
        <div class="text">
          <p>Banjir Mengguncang Kota Tasikmalaya Rabu 20 Maret 2020</p>
        </div>
        <span class="bgtext"></span>
        <img src="<?= BASEURL; ?>/image/sliders/slide2.png">
     </div>
     <div class="slide fade">
        <div class="text">
          <p>Asyik Coding Bersama SangIstri, 27 Maret 2022 WPU</p>
        </div>
        <span class="bgtext"></span>
        <img src="<?= BASEURL; ?>/image/sliders/slide3.png">
     </div>
     <div class="slide fade">
        <div class="text">
          <p>Inilah Tempat Coding WPU!</p>
        </div>
        <span class="bgtext"></span>
        <img src="<?= BASEURL; ?>/image/sliders/slide4.png">
     </div>
     <div class="slide fade">
        <div class="text">
          <p>Sosok Pak Dhika Dimata SangIstri, Ternyata Begini!</p>
        </div>
        <span class="bgtext"></span>
        <img src="<?= BASEURL; ?>/image/sliders/slide5.png">
     </div>
    <div class="dotsbox" style="text-align:center">
      <span class="dot" onclick="currentSlide(1)"></span>
      <span class="dot" onclick="currentSlide(2)"></span>
    </div>
  </header>
</div>

