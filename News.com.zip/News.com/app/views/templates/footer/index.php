<div class="container-footer">
  <footer class="footer">
    <div class="Fot-lines"></div>
    <h1>News.com</h1>
    <ul>
      <li><i class="fa-brands fa-facebook"></i></li>
      <li><i class="fa-brands fa-twitter"></i></li>
      <li><i class="fa-brands fa-instagram"></i></li>
      <li><i class="fa-brands fa-youtube"></i></li>
    </ul>
    <p>©opyright @ 2022 News.com,All rights reversed</p>
  </footer>
</div>
   <section>
   <script src="<?= BASEURL; ?>/javascript/script.js"></script>
  </body>
</html>

