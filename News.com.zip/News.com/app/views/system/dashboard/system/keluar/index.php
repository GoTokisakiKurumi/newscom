<?php

if ($_GET["url"] == "dashboard/keluar") {
  echo "class='dashactive'";
} else {
  echo "class='dashno-active'";
}
