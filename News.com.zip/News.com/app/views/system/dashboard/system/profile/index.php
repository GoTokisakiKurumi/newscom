<?php

if ($_GET["url"] == "dashboard/profile") {
  echo "class='dashactive-img'";
} else {
  echo "class='dashno-active'";
}

