<?php

if ($_GET["url"] == "dashboard/back") {
  echo "class='dashactive'";
} else {
  echo "class='dashno-active'";
}
