<div class="container-notfound">
  <div class="notfound">
    <i class="fa-solid fa-cloud"></i>
    <p>Data Not Found!</p>
  </div>
</div>
