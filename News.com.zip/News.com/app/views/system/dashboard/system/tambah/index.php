<?php

if ($_GET["url"] == "dashboard/tambah_berita") {
  echo "class='dashactive'";
} else {
  echo "class='dashno-active'";
}
