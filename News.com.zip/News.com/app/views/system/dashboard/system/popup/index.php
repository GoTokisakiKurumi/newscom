<div id="popup" class="container-popup hidde">
  <div class="popup-message">
    <h1>Apakah Kamu Yakin?</h1>
    <p>Anda tidak akan dapat mengembalikan ini</p>
  </div>
  <div class="popup-button">
    <a href="../hapus/<?= $data["detail"][0]["id_berita"]; ?>"><button>Iya, hapus!</button></a>
    <a href=""><button>Cancel</button></a>
  </div>
</div>

