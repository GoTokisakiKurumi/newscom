<?php

if ($_GET["url"] == "dashboard/message") {
  echo "class='dashactive'";
} else {
  echo "class='dashno-active'";
}
