<?php

define('BASEURL', 'http://localhost:8000/News.com/public');
define('SETURL', 'http://localhost:8000/News.com/home');

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'Newscom');
