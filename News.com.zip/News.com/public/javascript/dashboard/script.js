const btn = document.getElementById('btn');
const cls = document.getElementById('cls');
btn.addEventListener('click', function(){
  cls.classList.remove('blockAlert');
})
